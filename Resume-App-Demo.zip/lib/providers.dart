// providers.dart
import 'dart:convert';
import 'dart:io';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:http/http.dart' as http;
import 'package:http/io_client.dart';
import 'models/user.dart';

/// ---------- CUSTOMIZATION PROVIDERS ----------

// Font size (default 16)
final fontSizeProvider = StateProvider<double>((ref) => 16.0);

// Font color (default black)
final fontColorProvider = StateProvider<Color>((ref) => Colors.black);

// Background color (default white)
final backgroundColorProvider = StateProvider<Color>((ref) => Colors.white);

/// ---------- HTTP CLIENT (shared, pooled) ----------

final httpClientProvider = Provider<http.Client>((ref) {
  final ioHttp = HttpClient()
    ..maxConnectionsPerHost = 6
    ..idleTimeout = const Duration(seconds: 25);

  final client = IOClient(ioHttp);

  ref.onDispose(() {
    try {
      client.close();
    } catch (_) {}
  });

  return client;
});

/// ---------- RESUME FETCHING PROVIDER (fixed name in URL) ----------

final resumeProvider = FutureProvider<Welcome>((ref) async {
  final client = ref.watch(httpClientProvider);
  final uri = Uri.parse(
    "https://expressjs-api-resume-random.onrender.com/resume?name=Alice",
  );

  const int maxAttempts = 3;
  Duration backoff = const Duration(milliseconds: 500);

  for (int attempt = 1; attempt <= maxAttempts; attempt++) {
    try {
      final response = await client.get(uri).timeout(const Duration(seconds: 30));

      if (response.statusCode == 200 && response.body.isNotEmpty) {
        final data = jsonDecode(response.body);
        return Welcome.fromJson(data);
      } else {
        throw Exception('Server returned ${response.statusCode}');
      }
    } on TimeoutException catch (te) {
      debugPrint('Request timed out (attempt $attempt): $te');
      if (attempt == maxAttempts) rethrow;
    } catch (e) {
      debugPrint('Error fetching resume (attempt $attempt): $e');
      if (attempt == maxAttempts) {
        // fallback mock data
        return Welcome(
  name: "Alice",
  phone: "+1-555-1234-567",
  email: "user@example.com",
  twitter: "@exampleUser",
  address: "123 Main St, Anytown, USA",
  summary:
      "A passionate developer with experience in full-stack development, AI, and cloud computing.",
  skills: [
    "Kubernetes",
    "Express.js",
    "Docker",
  ],
  projects: [
    Project(
      title: "Social Media Dashboard by Alice",
      description:
          "Developed an analytics dashboard for social media insights.",
      startDate: DateTime.parse("2023-01-01"),
      endDate: DateTime.parse("2023-06-30"),
    ),
    Project(
      title: "Chat Application by Alice",
      description: "Implemented a chat system with real-time messaging.",
      startDate: DateTime.parse("2023-01-01"),
      endDate: DateTime.parse("2023-06-30"),
    ),
  ],
);

      }
    }

    await Future.delayed(backoff);
    backoff *= 2;
  }

  // Safety fallback
  return Welcome(
  name: "Alice",
  phone: "+1-555-1234-567",
  email: "user@example.com",
  twitter: "@exampleUser",
  address: "123 Main St, Anytown, USA",
  summary:
      "A passionate developer with experience in full-stack development, AI, and cloud computing.",
  skills: [
    "Kubernetes",
    "Express.js",
    "Docker",
  ],
  projects: [
    Project(
      title: "Social Media Dashboard by Alice",
      description:
          "Developed an analytics dashboard for social media insights.",
      startDate: DateTime.parse("2023-01-01"),
      endDate: DateTime.parse("2023-06-30"),
    ),
    Project(
      title: "Chat Application by Alice",
      description: "Implemented a chat system with real-time messaging.",
      startDate: DateTime.parse("2023-01-01"),
      endDate: DateTime.parse("2023-06-30"),
    ),
  ],
);

});
