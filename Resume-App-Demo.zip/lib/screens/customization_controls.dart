// lib/screens/customization_controls.dart
import 'package:flutter/material.dart';
import 'package:flutter_colorpicker/flutter_colorpicker.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../providers.dart';
import 'package:hive_flutter/hive_flutter.dart';

class CustomizationControls extends ConsumerWidget {
  const CustomizationControls({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final fontSize = ref.watch(fontSizeProvider);
    final fontColor = ref.watch(fontColorProvider);
    final bgColor = ref.watch(backgroundColorProvider);
    final box = Hive.isBoxOpen('newbox') ? Hive.box('newbox') : null;

    return SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Font size'),
            Slider(
              value: fontSize,
              min: 10,
              max: 36,
              divisions: 26,
              label: fontSize.toStringAsFixed(0),
              onChanged: (v) {
                ref.read(fontSizeProvider.notifier).state = v;
                box?.put('fontSize', v);
              },
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                const Text('Font color:'),
                const SizedBox(width: 8),
                GestureDetector(
                  onTap: () async => await _pickColor(context, ref, fontColorProvider),
                  child: Container(width: 28, height: 28, color: fontColor),
                ),
                const SizedBox(width: 12),
                Text('(${fontColor.value.toRadixString(16)})'),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                const Text('Background color:'),
                const SizedBox(width: 8),
                GestureDetector(
                  onTap: () async => await _pickColor(context, ref, backgroundColorProvider),
                  child: Container(width: 28, height: 28, color: bgColor),
                ),
                const SizedBox(width: 12),
                Text('(${bgColor.value.toRadixString(16)})'),
              ],
            ),
            const SizedBox(height: 16),
            ElevatedButton(onPressed: () => Navigator.of(context).pop(), child: const Text('Done')),
          ],
        ),
      ),
    );
  }
}

Future<void> _pickColor(BuildContext context, WidgetRef ref, StateProvider<Color> provider) async {
  Color chosen = ref.read(provider);
  final box = Hive.isBoxOpen('newbox') ? Hive.box('newbox') : null;

  await showDialog<void>(
    context: context,
    builder: (context) {
      return AlertDialog(
        title: const Text('Pick color'),
        content: SingleChildScrollView(
          child: ColorPicker(
            pickerColor: chosen,
            onColorChanged: (c) => chosen = c,
            showLabel: true,
            pickerAreaHeightPercent: 0.6,
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.of(context).pop(), child: const Text('Cancel')),
          TextButton(
            onPressed: () {
              ref.read(provider.notifier).state = chosen;
              if (provider == fontColorProvider) {
                box?.put('fontColor', chosen.value);
              } else {
                box?.put('bgColor', chosen.value);
              }
              Navigator.of(context).pop();
            },
            child: const Text('Select'),
          ),
        ],
      );
    },
  );
}
