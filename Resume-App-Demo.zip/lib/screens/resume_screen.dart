// resume_screen.dart
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:location/location.dart';
import '../models/user.dart';
import '../providers.dart';
import 'customization_controls.dart';

class ResumeScreen extends ConsumerStatefulWidget {
  const ResumeScreen({super.key});

  @override
  ConsumerState<ResumeScreen> createState() => _ResumeScreenState();
}

class _ResumeScreenState extends ConsumerState<ResumeScreen> {
  final Location _location = Location();
  StreamSubscription<LocationData>? _sub;

  double lat = 0.0;
  double lon = 0.0;

  @override
  void initState() {
    super.initState();
    _initLocation();
    // refresh the fixed-name provider on startup
    Future.microtask(() => ref.refresh(resumeProvider));
  }

  Future<void> _initLocation() async {
    bool serviceEnabled = await _location.serviceEnabled();
    if (!serviceEnabled) {
      serviceEnabled = await _location.requestService();
      if (!serviceEnabled) return;
    }

    PermissionStatus permissionGranted = await _location.hasPermission();
    if (permissionGranted == PermissionStatus.denied) {
      permissionGranted = await _location.requestPermission();
      if (permissionGranted != PermissionStatus.granted) return;
    }

    _sub = _location.onLocationChanged.listen((locationData) {
      if (!mounted) return;
      setState(() {
        lat = locationData.latitude ?? 0.0;
        lon = locationData.longitude ?? 0.0;
      });
    });
  }

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final fontSize = ref.watch(fontSizeProvider);
    final fontColor = ref.watch(fontColorProvider);
    final bgColor = ref.watch(backgroundColorProvider);

    // watch the provider (fixed name "Alice" in URL)
    final asyncValue = ref.watch(resumeProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text("Resume Demo"),
        actions: [
          IconButton(
            icon: const Icon(Icons.tune),
            onPressed: () => showModalBottomSheet(
              context: context,
              builder: (_) => const Padding(
                padding: EdgeInsets.all(12),
                child: CustomizationControls(),
              ),
            ),
          ),
          // Optional: manual refresh button
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: () => ref.refresh(resumeProvider),
            tooltip: 'Refresh resume',
          ),
        ],
      ),
      body: Container(
        color: bgColor,
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // LOCATION FEED AT TOP
            Row(
              children: [
                const Icon(Icons.location_on_outlined, size: 18, color: Colors.blueAccent),
                const SizedBox(width: 6),
                Expanded(
                  child: Text(
                    "Lat: ${lat.toStringAsFixed(5)}, Lon: ${lon.toStringAsFixed(5)}",
                    style: const TextStyle(fontSize: 13),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),

            // Resume Info (auto-fetched)
            Expanded(
              child: asyncValue.when(
                loading: () => const Center(child: CircularProgressIndicator()),
                error: (err, stack) => Center(
                  child: Text(
                    'Failed to load data.\n$err',
                    style: const TextStyle(color: Colors.redAccent),
                    textAlign: TextAlign.center,
                  ),
                ),
                data: (user) => SingleChildScrollView(
                  padding: const EdgeInsets.all(8),
                  child: Text(
                    _formatUser(user),
                    style: TextStyle(fontSize: fontSize, color: fontColor),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  String _formatUser(Welcome u) {
  // Normalize skills to a list of strings (handles nullable or non-nullable models)
  final List<String> skillsList = (u.skills ?? <String>[]).map((s) => s.toString()).toList();
  final skills = skillsList.isEmpty ? "No skills" : skillsList.join(", ");

  // Normalize projects: accept Project instances, strings, or maps
  final List<dynamic> rawProjects = u.projects ?? <dynamic>[];
  String _projectToLabel(dynamic p) {
    if (p == null) return "";
    // If you have access to the Project type, the `is Project` branch will be used.
    try {
      // If it's a Project instance, return its title
      if (p is Project) return p.title;
    } catch (_) {} // ignore if Project type is not in scope

    // If it's already a string (maybe you stored titles), use it
    if (p is String) return p;

    // If it's a map-like structure (Map<String, dynamic>), try to read the 'title' key
    if (p is Map) return (p['title']?.toString() ?? p.toString());

    // Fallback: call toString()
    return p.toString();
  }

  final List<String> projectLabels = rawProjects.map(_projectToLabel).where((s) => s.isNotEmpty).toList();
  final projects = projectLabels.isEmpty ? "No projects" : projectLabels.join(", ");

  return """
Name: ${u.name}

Skills:
  $skills

Projects:
  $projects

""";
}

}
