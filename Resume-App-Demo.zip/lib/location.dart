// lib/location.dart
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:location/location.dart';
import 'package:permission_handler/permission_handler.dart';

class GetLocation extends StatefulWidget {
  const GetLocation({super.key});

  @override
  State<GetLocation> createState() => _GetLocationState();
}

class _GetLocationState extends State<GetLocation> with WidgetsBindingObserver {
  final Location _location = Location();
  StreamSubscription<LocationData>? _sub;
  double latitude = 0.0;
  double longitude = 0.0;
  bool _listening = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _startLocationStream();
  }

  @override
  void dispose() {
    _sub?.cancel();
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  Future<void> _startLocationStream() async {
    // request permission using permission_handler
    final status = await Permission.locationWhenInUse.status;
    if (!status.isGranted) {
      final res = await Permission.locationWhenInUse.request();
      if (!res.isGranted) {
        // cannot start
        return;
      }
    }

    // ensure service is enabled
    final serviceEnabled = await _location.serviceEnabled();
    if (!serviceEnabled) {
      final enabled = await _location.requestService();
      if (!enabled) return;
    }

    if (_listening) return;
    _listening = true;

    // configure desired accuracy & interval as needed
    await _location.changeSettings(interval: 1000, accuracy: LocationAccuracy.high);

    _sub = _location.onLocationChanged.listen((loc) {
      if (!mounted) return;
      setState(() {
        latitude = loc.latitude ?? latitude;
        longitude = loc.longitude ?? longitude;
      });
    }, onError: (e) {
      // swallow or optionally show error
      debugPrint('Location stream error: $e');
    });
  }

  Future<void> fetchOnce() async {
    try {
      final loc = await _location.getLocation();
      setState(() {
        latitude = loc.latitude ?? latitude;
        longitude = loc.longitude ?? longitude;
      });
    } catch (e) {
      debugPrint('getLocation error: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text('Latitude: ${latitude.toStringAsFixed(6)}'),
        Text('Longitude: ${longitude.toStringAsFixed(6)}'),
        const SizedBox(height: 8),
        ElevatedButton(
          onPressed: fetchOnce,
          child: const Text('Get location'),
        ),
      ],
    );
  }
}
