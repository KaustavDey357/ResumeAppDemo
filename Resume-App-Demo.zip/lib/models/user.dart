// lib/models/user.dart
import 'dart:convert';

// To parse this JSON data, do:
//
//     final welcome = welcomeFromJson(jsonString);

Welcome welcomeFromJson(String str) => Welcome.fromJson(json.decode(str));
String welcomeToJson(Welcome data) => json.encode(data.toJson());

class Welcome {
  String name;
  String phone;
  String email;
  String twitter;
  String address;
  String summary;
  List<String> skills;
  List<Project> projects;

  Welcome({
    required this.name,
    required this.phone,
    required this.email,
    required this.twitter,
    required this.address,
    required this.summary,
    required this.skills,
    required this.projects,
  });

  factory Welcome.fromJson(Map<String, dynamic> json) => Welcome(
        name: json["name"] ?? "",
        phone: json["phone"] ?? "",
        email: json["email"] ?? "",
        twitter: json["twitter"] ?? "",
        address: json["address"] ?? "",
        summary: json["summary"] ?? "",
        skills: json["skills"] == null
            ? []
            : List<String>.from(json["skills"].map((x) => x.toString())),
        projects: json["projects"] == null
            ? []
            : List<Project>.from(
                json["projects"].map((x) => Project.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "name": name,
        "phone": phone,
        "email": email,
        "twitter": twitter,
        "address": address,
        "summary": summary,
        "skills": List<dynamic>.from(skills.map((x) => x)),
        "projects": List<dynamic>.from(projects.map((x) => x.toJson())),
      };
}

class Project {
  String title;
  String description;
  DateTime startDate;
  DateTime endDate;

  Project({
    required this.title,
    required this.description,
    required this.startDate,
    required this.endDate,
  });

  factory Project.fromJson(Map<String, dynamic> json) => Project(
        title: json["title"] ?? "",
        description: json["description"] ?? "",
        startDate:
            DateTime.tryParse(json["startDate"] ?? "") ?? DateTime(1970, 1, 1),
        endDate:
            DateTime.tryParse(json["endDate"] ?? "") ?? DateTime(1970, 1, 1),
      );

  Map<String, dynamic> toJson() => {
        "title": title,
        "description": description,
        "startDate":
            "${startDate.year.toString().padLeft(4, '0')}-${startDate.month.toString().padLeft(2, '0')}-${startDate.day.toString().padLeft(2, '0')}",
        "endDate":
            "${endDate.year.toString().padLeft(4, '0')}-${endDate.month.toString().padLeft(2, '0')}-${endDate.day.toString().padLeft(2, '0')}",
      };
}
